﻿export enum Role {
    teamlead = 'teamlead',
    developer = 'developer',
    hrmanager='hrmanager'
}