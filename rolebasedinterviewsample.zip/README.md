# angular-8-role-based-authorization-example

Angular 8 - Role Based Authorization Example with the Angular CLI

For tutorial and live demo see https://jasonwatmore.com/post/2019/08/06/angular-8-role-based-authorization-tutorial-with-example